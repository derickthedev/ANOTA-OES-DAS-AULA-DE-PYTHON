"""
EXERCÍCIO 001: Olá, Mundo!

Crie um programa que escreva "Olá, Mundo!" na tela.
"""
msg = 'Olá, Mundo!'
print(msg)
