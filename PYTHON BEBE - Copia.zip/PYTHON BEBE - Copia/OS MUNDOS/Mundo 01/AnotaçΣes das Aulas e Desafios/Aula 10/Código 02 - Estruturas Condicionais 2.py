tempo = int(input('Quantos anos tem seu carro? '))
print('Carro novo!' if tempo <= 3 else 'Carro velho!')  # Simplificação de uma Estrutura Condicional
print('--- FIM ---')
