"""
DESAFIO 003.1: Somando Dois Números

Crie um programa que leia dois números e mostre a soma entre eles.
"""
n1 = int(input('Primeiro número: '))
n2 = int(input('Segundo número: '))
re = n1 + n2
print('A soma de', n1, 'mais', n2, 'é', re)
