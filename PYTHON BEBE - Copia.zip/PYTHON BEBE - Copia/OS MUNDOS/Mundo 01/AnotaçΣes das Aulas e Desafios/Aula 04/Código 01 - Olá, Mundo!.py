# NOTA: Dar preferência às aspas simples (') ao invés das aspas duplas (").
print('Olá, Mundo!')
