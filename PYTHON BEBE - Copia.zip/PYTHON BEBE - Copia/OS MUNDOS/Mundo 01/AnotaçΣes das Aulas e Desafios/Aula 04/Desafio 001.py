"""
DESAFIO 001: Olá, Mundo!

Crie um programa que escreva "Olá, Mundo!" na tela.
"""
nome = input('Qual é o seu nome? ')
print('Olá', nome, '! Prazer em te conhecer!')
