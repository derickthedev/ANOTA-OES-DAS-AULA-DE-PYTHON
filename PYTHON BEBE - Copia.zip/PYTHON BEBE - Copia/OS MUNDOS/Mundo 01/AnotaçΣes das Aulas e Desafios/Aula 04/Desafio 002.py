"""
DESAFIO 002: Respondendo ao Usuário

Faça um programa que leia o nome de uma pessoa e mostre uma mensagem de boas-vindas.
"""
dia = input('Dia = ')
mes = input('Mês = ')
ano = input('Ano = ')
print('Você nasceu no dia', dia, 'de', mes, 'de', ano, '. Correto?')
