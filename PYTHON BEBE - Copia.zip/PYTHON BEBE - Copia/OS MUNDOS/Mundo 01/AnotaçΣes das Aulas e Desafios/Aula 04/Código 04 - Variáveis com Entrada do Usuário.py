# Variáveis atribuídas com os valores inseridos pelo usuário
nome = input('Qual é o seu nome? ')
idade = input('Qual é a sua idade? ')
peso = input('Qual é o seu peso? ')

# Comando de exibir as variáveis na tela
print(nome, idade, peso)
