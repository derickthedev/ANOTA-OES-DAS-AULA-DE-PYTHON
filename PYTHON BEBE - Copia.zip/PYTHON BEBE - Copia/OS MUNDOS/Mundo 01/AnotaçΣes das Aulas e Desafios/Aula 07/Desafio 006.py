"""
DESAFIO 006: Dobro, Triplo, Raiz Quadrada

Crie um algoritmo que leia um número e mostre o seu dobro, triplo e raiz quadrada.
"""
n = int(input('Digite um número: '))
print('O número digitado foi {}, o dobro é {}, o triplo é {} e a raiz quadrada é {}.'.format(n, n * 2, n * 3, n ** (1/2)))
