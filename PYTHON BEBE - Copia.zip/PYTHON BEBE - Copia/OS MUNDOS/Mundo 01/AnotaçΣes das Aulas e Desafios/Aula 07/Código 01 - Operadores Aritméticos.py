# Operadores Aritméticos
print(5 + 2)  # Adição
print(5 - 2)  # Subtração
print(5 * 2)  # Multiplicação
print(5 / 2)  # Divisão
print(5 ** 2)  # Potência/Exponenciação - Método 1
print(pow(5, 2))  # Potência/Exponenciação - Método 2
print(5 // 2)  # Divisão Inteira
print(5 % 2)  # Resto da Divisão
print(81 ** (1/2))  # Raiz Quadrada
