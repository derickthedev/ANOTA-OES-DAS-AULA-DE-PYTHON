# Diferentes Usos dos Operadores Aritméticos
print('Oi' * 5)  # Exibe a palavra "Oi" 5 vezes
print('=' * 20)  # Exibe o sinal de "=" 20 vezes
