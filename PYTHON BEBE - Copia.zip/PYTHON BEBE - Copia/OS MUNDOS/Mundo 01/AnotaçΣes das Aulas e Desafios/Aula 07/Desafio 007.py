"""
DESAFIO 007: Média Aritmética

Desenvolva um programa que leia as duas notas de um aluno, calcule e mostre a sua média.
"""
nt1 = float(input('Digite a primeira nota: '))
nt2 = float(input('Digite a segunda nota: '))
media = (nt1 + nt2) / 2
print('A primeira nota foi {}, a segunda nota foi {} e a média entre elas é {}.'.format(nt1, nt2, media))
