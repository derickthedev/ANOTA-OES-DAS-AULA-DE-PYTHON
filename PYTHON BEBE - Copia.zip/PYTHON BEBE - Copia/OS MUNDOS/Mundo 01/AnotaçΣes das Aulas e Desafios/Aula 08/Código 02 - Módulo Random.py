import random  # Importa o Módulo random com todas as suas funções
num1 = random.random()  # Atribui à variável "num1" um valor aleatório float entre 0 e 1
num2 = random.randint(1, 10)  # Atribui à variável "num2" um valor aleatório int entre 1 e 10
print(num1, num2)  # Exibe os valores gerados
