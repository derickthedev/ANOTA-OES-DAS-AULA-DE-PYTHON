"""
DESAFIO 021: Tocando um MP3

Faça um programa em Python que abra e reproduza o áudio de um arquivo MP3.
"""
from playsound import playsound
playsound('musica.mp3')
