"""
DESAFIO 003.2: Somando Dois Números

Crie um programa que leia dois números e mostre a soma entre eles.
"""
n1 = int(input('Digite o primeiro número: '))
n2 = int(input('Digite o segundo número: '))
r = n1 + n2
print('A soma entre {} e {} vale {}!'.format(n1, n2, r))
