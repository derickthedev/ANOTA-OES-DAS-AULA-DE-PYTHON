"""
Usando aspas triplas dentro dos parênteses do comando "print", ao invés do texto se tornar meramamente
um comentário ignorando pelo Python, como este, é possível exibir um texto inteiro com várias linhas,
sem precisar repetir o "print" em cada uma delas.
"""

print('''Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Cras aliquam sapien non augue pharetra finibus. Integer ac justo quam.
Pellentesque at eros vel tortor pharetra mollis sit amet convallis sem.
Cras vel lobortis metus. Donec metus magna, fermentum eget dolor at, egestas dapibus sem.
Etiam varius, enim ut tincidunt tristique, dui risus tristique quam, id iaculis ipsum sem nec elit.
Nunc iaculis sit amet diam id lobortis. Nam egestas congue lectus vitae maximus.''')
