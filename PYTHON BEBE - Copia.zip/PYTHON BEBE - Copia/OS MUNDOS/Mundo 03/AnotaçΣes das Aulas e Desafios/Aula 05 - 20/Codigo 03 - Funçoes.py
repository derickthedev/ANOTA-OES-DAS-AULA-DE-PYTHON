"""
Podemos definir uma funçao com numerais,como exemplo em uma soma afim da varial assumir o valor numeral
"""



#Codigo de uma soma

a = 1
b = 2
soma = a + b
print(soma)

a = 3 
b = 4 
soma = a + b
print(soma)

a = 5
b = 6
soma = a + b
print(soma)



"""
se torna observavel que a estipulaçao de uma certa estrutura se faz ocorrente,o que pode ser chamada de soma.Podemos estipular uma funçao que reduçao da massividade de escriçao.
"""



#Codigo soma de 2 variaveis

def soma(a, b):     #-----> o parametro é que existao 2 numeros seja la quais forem.
    soma = a + b    #-----> bloco de codigo.(operaçao de soma e mostragem de resultado)
    print(soma)

soma(1, 2)
soma(3, 4)
soma(5, 6)



"""
nota-se que nao estipulaçao da funçao no parametro a apenas 2 variaveis,e a uma pergunta que refere-se a assim,"podemos adicionar 3 numeros na soma?".Podemos somar apenas o que foi defiinido 
na funçao,se o ultrapassar 2 variaveis ocorrerá um erro.Podemos concluir,quando pensamos em funçao temos que pensar sempre em seguir os parametros que propriamente definimos.
"""



#codigo soma de 2 variaveis errado

def soma(a, b):     #-----> o parametro é que existao 2 numeros seja la quais forem.
    soma = a + b    #-----> bloco de codigo.(operaçao de soma e mostragem de resultado)
    print(soma)

soma(1, 2)
soma(3, 4, 8)   #-----> a 3 variaveis,mas a funçao foi definida apenas para 2.
soma(5, 6, 9, 2)    #-----> a 4 variaveis,mas a funçao foi definida apenas para 2.



"""
devemos destacar tambem que a  como definir qual valor tera certo parametro.
"""



#codigo soma com variaveis definidas no parametro

def soma(a, b):   
    soma = a + b    
    print(soma)

soma(a=1, b=2)  #----->observe a definiçao cada valor definido exatamente com a variaevel no parametro.
soma(b=3, a=4)  #----->observe apenas a inversao das dos valores atribuidas a cada variavel.
soma(4, 8)  #-----> importante se observar que quando nao esta atribuindo exato valor a cada parametro ele simplemente assume de acordo com o parametro da funçao primeira 'a' depois 'b'
            # portanto 'a' = 4 e 'b' = 8,nunca 'a' = 8 e 'b' = 4



