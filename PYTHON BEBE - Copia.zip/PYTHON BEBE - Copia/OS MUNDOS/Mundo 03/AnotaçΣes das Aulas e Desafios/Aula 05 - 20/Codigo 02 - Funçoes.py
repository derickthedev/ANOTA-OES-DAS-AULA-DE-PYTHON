"""
podemos entender que a funçoes nao nessariamente precisao de apenas um bloco de codigo propriamente definido,podemos definir o codigo de acordo ocm a necessidade.

"""

#codigo sem funçao observando estrutura

print('---------------------------------------') #<-----.
print('texto 1')                                 #<-------->Bloco observavel,percebe-se sua repetiçao mudando apenas seu miolo.         
print('---------------------------------------') #<-----'

print('---------------------------------------')
print('texto 2')
print('---------------------------------------')

print('---------------------------------------')
print('texto 3')
print('---------------------------------------')

"""
podemos assim definir a estrutura de forma de funçao

"""

#codigo da funçao da estrutura com parametro 

def estrutura(texto): #-----> o 'texto' é o parametro.
    print('---------------------------------------')
    print(texto) #----->nao importa o texto,ele irá aparecer aqui.
    print('---------------------------------------')

estrutura('texto 1') #-----> chama-se a funçao com o parametro definido.
estrutura('texto 2')
estrutura('texto 3')












