
"""
Existem várias funções internas do próprio Python que usamos e talvez nem tenhamos percebido, como por exemplo: print(), len(), type(), int(), str(), entre outras.

basicamente uma funçao é utilizada quando temos uma rotina muito utilizada no nosso caso de sempre mostrar uma linha
"""


#codigo sem funçao 


print('---------------------------------------')
print('texto 1')
print('---------------------------------------')

print('---------------------------------------')
print('texto 2')
print('---------------------------------------')

print('---------------------------------------')
print('texto 3')
print('---------------------------------------')


"""
Aqui podemos perceber claramente a utilizaçao maçante de linha para dividir os texto.Funçoes vinheram para facilitar seu dia a dia executando uma rotina.

Podemos descrever assim uma funçao linha para utilizamos a linha quando bem entendermos.
"""

#codigo com funçao 

def linha(): #-----> Funçao definida
    print('---------------------------------------') #-----> Bloco de comando executavel da funçao.
    
linha() #-----> Requisiçao para a utilizaçao da funçao definida e aplicaçao do bloco ed comando
print('texto 1')
linha()

linha()
print('texto 2')
linha()

linha()
print('texto 3')
linha()







