"""
EXERCÍCIO 047: Contagem de Pares

Crie um programa que mostre na tela todos os números pares que estão no intervalo entre 1 e 50.
"""
for n in range(2, 51, 2):
    print(n, end=' ')
print('Acabou')
