"""
DESAFIO 047: Contagem de Pares

Crie um programa que mostre na tela todos os números pares que estão no intervalo entre 1 e 50.
"""
print('Todos os números pares entre 1 e 50:')
for c in range(2, 50 + 1, 2):
    print(c, end=' ')
