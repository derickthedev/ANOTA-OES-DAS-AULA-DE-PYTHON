'''
DESAFIO 084: Lista Composta e Análise de Dados

Faça um programa que leia nome e peso de várias pessoas, guardando tudo em uma lista. No final, mostre:

A) Quantas pessoas foram cadastradas.
B) Uma listagem com as pessoas mais pesadas.
C) Uma listagem com as pessoas mais leves.
'''

dados = list()
nomepeso = list()



while True:
    nomepeso.append(str(input('Qual o seu nome?:')))
    nomepeso.append(int(input('Qual seu peso?: ')))
    dados.append(nomepeso[:])
    nomepeso.clear()
    print(f'Os correspondentes dados sao: {dados}')

    novamente = input('deseja continuar? [s/n]: ').lower()
    if novamente not in ('s', 'n'):
        print('tente novamente...')
        novamente = input('deseja continuar? [s/n]: ').lower()

    if novamente == 'n':
        break

print(f"""
A SUA LISTA FICOU ASSIM:
      
{dados}          
""")










