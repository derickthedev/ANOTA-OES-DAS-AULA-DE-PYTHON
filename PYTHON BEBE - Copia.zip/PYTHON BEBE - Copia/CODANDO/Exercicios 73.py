'''
DESAFIO 073: Tuplas com Times de Futebol

Crie uma tupla preenchida com os 20 primeiros colocados da Tabela
do Campeonato Brasileiro de Futebol, na ordem de colocação.
Depois mostre:

A) Os 5 primeiros.
B) Os últimos 4 colocados.
C) Times em ordem alfabética.
D) Em que posição está o time que eu querer saber.
'''

div = '='*50
print(div)

times = (
'Clube Atlético Mineiro',
'Esporte Clube Bahia',
'Botafogo de Futebol e Regatas',
'Ceará Sporting Club',
'Sport Club Corinthians Paulista',
'Cruzeiro Esporte Clube',
'Clube de Regatas do Flamengo',
'Fluminense Football Club',
'Fortaleza Esporte Clube',
'Grêmio Foot-Ball Porto Alegrense',
'Sport Club Internacional',
'Esporte Clube Juventude',
'Mirassol Futebol Clube',
'Sociedade Esportiva Palmeiras',
'Red Bull Bragantino',
'Santos Futebol Clube',
'São Paulo Futebol Clube',
'Sport Club do Recife',
'Club de Regatas Vasco da Gama',
'Esporte Clube Vitória'
)
print( times)

print(div)

print(f'os 5 primeiros colocados sao:\n{times[0:5]}')

print(div)

print(f'os 4 ultimos coloados sao:\n{times[16:21]}')

print(div)

print(f'os os times os times em ordem alfabetica:\n{sorted(times)}')

print(div)

print(f'o time do fortaleza esta na posiçao:\n{times.index("Fortaleza Esporte Clube") + 1}')

print(div)



 




