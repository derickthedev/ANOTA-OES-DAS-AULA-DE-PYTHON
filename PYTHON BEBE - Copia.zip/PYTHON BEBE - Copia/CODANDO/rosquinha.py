import os
import math
import time
import sys

shades = ".,-~:;=!*#$@"


def clear():
    os.system("cls" if os.name == "nt" else "clear")

def render_frame(A, B):
    width, height = 80, 24
    output = [' '] * (width * height)
    zbuffer = [0] * (width * height)

    for j in range(0, 628, 7):  
        for i in range(0, 628, 2):
            c = math.sin(i / 100)
            d = math.cos(j / 100)
            e = math.sin(A)
            f = math.sin(j / 100)
            g = math.cos(A)
            h = d + 2
            D = 1 / (c * h * e + f * g + 5)
            l = math.cos(i / 100)
            m = math.cos(B)
            n = math.sin(B)
            t = c * h * g - f * e
            x = int(width/2 + (width / 4) * D * (l * h * m - t * n))
            y = int(height/2 + (width / 8) * D * (l * h * n + t * m))
            o = x + width * y
            N = int(8 * ((f * e - c * d * g) * m - c * d * e - f * g - l * d * n))

            if 0 <= x < width and 0 <= y < height and D > zbuffer[o]:
                zbuffer[o] = D
                output[o] = shades[max(N, 0) % len(shades)]

    clear()
    for i in range(0, len(output), width):
        line = ''.join(output[i:i+width])
        print(line)

def main():
    A = 0
    B = 0
    try:
        while True:
            render_frame(A, B)
            A += 0.04
            B += 0.08
            time.sleep(0.03)
    except KeyboardInterrupt:
        print("\nEncerrado.")

main()
