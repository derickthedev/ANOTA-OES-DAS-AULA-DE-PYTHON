'''
DESAFIO 081: Extraindo Dados de uma Lista

Crie um programa que vai ler vários números e colocar em uma lista. Depois disso, mostre:

A) Quantos números foram digitados.
B) A lista de valores, ordenada de forma decrescente.
C) Se quaisquer o valor que o usuario digitar está ou não na lista.
'''


lista = []

while True:
    num = int(input('Digite um número que você quer colocar na lista: '))
    lista.append(num)
    print(lista)
    decisao = input('Deseja continuar [s/n]: ').lower()
    while decisao not in ('s', 'n'):
        decisao = input('Por favor, digite apenas "s" para continuar ou "n" para parar: ').lower()
    if decisao == 'n':
        break

print(f'\nA) Foram digitados {len(lista)} números.')
print(f'B) Lista ordenada de forma decrescente: {sorted(lista, reverse=True)}')

while True:
    escolha = int(input('digite o numero que deseja ver se esta na lista: '))
    if escolha not in lista:
        print('este numero nao esta condido na lista!')
    else:
        print('este numero esta contido na lista!')

    decisao = input('Deseja continuar [s/n]: ').lower()

    while decisao not in ('s', 'n'):
        decisao = input('Por favor, digite apenas "s" para continuar ou "n" para parar: ').lower()
    if decisao == 'n':
        print('programa encerrando...')
        break