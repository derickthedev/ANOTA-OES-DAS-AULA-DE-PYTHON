"""
fazer um programa que tenha opçoes de cadastratamento,listagem,manipulaçoes e saida,os sistema sera utilizado por uma loja de aparelhos tecnologicos
afim de controlar o o que tem no estoque e substituir aparelhos com bases em suas condicoes de estado e tipo de clientes,formando um algoritmo dete-
rminado para certa faixa etaria de idade.
"""


#region Painel de escolha do cliente ou funcionario

div = '=' * 100
print(div)
print(
"""
OLA,BEM VINDO A LOJA,INFORME POR FAVOR OS CAMPOS ABAIXO...

[1] SOU FUNCIONARIO
[2] SOU CLIENTE
"""    
)
print(div)

while True:

    painel_escolha = int(input('Escolha uma das opçoes acima: '))
    if painel_escolha not in (1,2):
        print('Esta opçao nao consta no painel,digite novamente')
    elif painel_escolha in (1,2):
        break

print(div)

#endregion

#region validaçao de funcionario

dados = {
    "funcionario1": {'usuario': 'gustavo', 'senha': 1245},
    "funcionario2": {'usuario': 'ana', 'senha':6548},
    "funcionario3": {'usuario': 'joao', 'senha': 3263}
}   


if painel_escolha == 1:
    print("""
    Bem vindo a empresa...Por favor apresente os seguintes dados:
    [1] Usuario
    [2] Senha
          
    """)
    usuario = input('informe a seu usuario: ')
    senha = input('informe a sua senha:')

    while True:
        usuario_encontrado = False
        for funcionario in dados.values():
            if usuario == funcionario['usuario']:
                if senha == str(funcionario['senha']):
                    print('<<<usuario encontrado>>>')
                    print('<<<acesso concedido>>>')
                    usuario_encontrado = True
                    break
                else:
                    print('Senha incorreta.')
                    usuario_encontrado = True
                    break
        if usuario_encontrado:
            if senha == str(funcionario['senha']):
                break  # Sai do loop se acesso concedido ou senha incorreta
            else:
                # Se senha incorreta, pede novamente a senha
                senha = input('Senha incorreta. Informe a sua senha novamente: ')
        else:
            print('<<<acesso negado>>>')
            print('Usuario nao encontrado.')
            usuario = input('informe a seu usuario: ')
            senha = input('informe a sua senha:')

#endregion 

#region Menu cliente    
itens_informatica = {
    "item1": {"item": "Mouse", "ano": 1964},
    "item2": {"item": "Teclado", "ano": 1970},
    "item3": {"item": "Monitor CRT", "ano": 1973},
    "item4": {"item": "Disquete", "ano": 1971},
    "item5": {"item": "CD-ROM", "ano": 1982},
    "item6": {"item": "HD (Disco Rígido)", "ano": 1956},
    "item7": {"item": "SSD", "ano": 1991},
    "item8": {"item": "Pendrive", "ano": 2000},
    "item9": {"item": "Impressora matricial", "ano": 1970},
    "item10": {"item": "Scanner", "ano": 1984},
    "item11": {"item": "Notebook", "ano": 1981},
    "item12": {"item": "Placa-mãe", "ano": 1981},
    "item13": {"item": "Processador Intel 4004", "ano": 1971},
    "item14": {"item": "Memória RAM", "ano": 1947},
    "item15": {"item": "Fonte ATX", "ano": 1995},
    "item16": {"item": "Placa de vídeo dedicada", "ano": 1999},
    "item17": {"item": "Mouse óptico", "ano": 1999},
    "item18": {"item": "Monitor LCD", "ano": 1998},
    "item19": {"item": "Wi-Fi (802.11b)", "ano": 1999},
    "item20": {"item": "Bluetooth", "ano": 1999}
}

print("""
OLA CLIENTE...SEJA BEM VINDO.   

[1] Ver itens na loja
[2] Verificar promoçoes ou descontos
[3] Sair
""")
while True:
    escolha = str(input('Por favor escolha uma das opçoes acima.\n>>>'))
    if escolha == '1': 
        print('Estes sao os itens da loja:')
        for v in itens_informatica.values():
            print(f"{v['item']} - Ano: {v['ano']}")
        print('='*100)
        while True:
            compra1 = input('Deseja comprar algo? [S/N]:').upper()
            if compra1 == 'S':
                item = input('Qual item voçe deseja comprar: ')
                encontrado = False
                for v in itens_informatica.values():
                    if item.lower() == v['item'].lower():
                        print(f'{v["item"]} ... este item foi adicionado ao seu carrinho e debitado da sua conta.')
                        encontrado = True
                        break
                if not encontrado:
                    print('Item não encontrado na loja.')
                compra = input('Mais alguma coisa? [S/N]: ').upper()
                if compra != 'S':
                    break

    if escolha == '2':
        print("""Aqui estao as promoçoes e descontos:""")
        
        break
    if escolha == '3':
        print('Saindo...')
        break
    else:
        print('Opção inválida. Tente novamente.')




#endregion





















