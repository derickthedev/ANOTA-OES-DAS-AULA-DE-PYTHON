#EXERCÍCIO 078: Maior e Menor Valores na Lista

#Faça um programa que leia 5 valores numéricos e guarde-os em uma lista. No final, mostre
#qual foi o maior e o menor valor digitado e as suas respectivas posições na lista.

valores = []


while True:
    valoresdigitados = input('digite valores para colocar em sua lista: ')
    valores.append(valoresdigitados)
    novamente = input('dejesas colocar mais um numer negro? (s/n): ').lower()
    
    if  novamente == 's':
        valoresdigitados
    if novamente == 'n':
        break

print(f'os valores que voçe colocou os respectivos valores: {valores}')

maior = max(valores) 
menor = min(valores)

posicoes_maior = [i for i, v in enumerate(valores) if v == maior]
posicoes_menor = [i for i, v in enumerate(valores) if v == menor]

print(f'O maior valor está nas posições: {posicoes_maior}')
print(f'O menor valor está nas posições: {posicoes_menor}')