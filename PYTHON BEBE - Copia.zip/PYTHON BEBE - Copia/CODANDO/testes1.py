"""
Crie um programa onde o usuário possa digitar cinco valores numéricos e cadastre-os em uma lista,
já na posição correta de inserção (sem usar o sort()). No final, mostre a lista ordenada na tela.

"""
'''
lista = list()

for numero in range(0, 5):
    valor = int(input('Digite um valor: '))
    
    if numero == 0 or valor > lista[-1]:
        lista.append(valor)
        print('Adicionado ao final da lista...')

    else:
        for i, v in enumerate(lista):
            if valor <= v:
                lista.insert(i, valor)
                print(f'Adicionado na posição {i} da lista...')
                break

print('-=' * 30)
print(f'Os valores digitados em ordem foram {lista}')

'''

lista = list()

while True:
    print("""
[1] Adicionar um número 
[2] Retirar um número 
[3] Reposicionar ou modificar o número
[4] Sair
""")
    escolha = int(input('Selecione uma das opções: '))

    if escolha == 1:
        while True:

            valores = int(input('Digite um valor: '))
            lista.append(valores)
            print(f'Sua lista ficou assim:\n{lista}')
            decisao = input('Deseja continuar adicionando? <s/n>: ').lower()

            if decisao == 'n':
                print('Operação finalizada.')
                break

    elif escolha == 2:
        while True:

            if not lista:
                print('A lista está vazia.')
                break

            retirar = int(input('Digite o índice do valor a ser retirado: '))

            if 0 <= retirar < len(lista):
                lista.pop(retirar)
                print(f'Sua lista ficou assim:\n{lista}')

            else:
                print('Índice inválido.')
            decisao = input('Deseja continuar retirando? <s/n>: ').lower()

            if decisao == 'n':
                print('Operação finalizada.')
                break

    elif escolha == 3:
        while True:

            if not lista:
                print('A lista está vazia.')
                break
            print(f'Sua lista atual: {lista}')

            indice = int(input('Indique o índice do elemento que deseja modificar: '))

            if 0 <= indice < len(lista):
                novo_valor = int(input('Digite o novo valor para esse índice: '))
                lista[indice] = novo_valor
                print(f'Sua lista ficou assim:\n{lista}')

            else:
                print('Índice inválido.')
                
            decisao = input('Deseja continuar modificando? <s/n>: ').lower()

            if decisao == 'n':
                print('Operação finalizada.')
                break

    elif escolha == 4:
        print('Saindo do programa.')
        break

    else:
        print('Opção inválida. Tente novamente.')














