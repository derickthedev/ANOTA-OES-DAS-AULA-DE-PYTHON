'''
DESAFIO 086: Matriz em Python

Crie um programa que crie uma matriz de dimensão 3x3 e preencha com valores lidos pelo teclado.

0 [_][_][_]
1 [_][_][_]
2 [_][_][_]
   0  1  2

No final, mostre a matriz na tela, com a formatação correta.
'''

matriz = [
[],
[],
[]
]

while True:
    for linha in range(0,3):
        for coluna in range(0,3):
            numero = int(input(f'digite o valor atribuido a linha {linha} coluna {coluna}:'))
            matriz[linha].append(numero)
            print(f'[ {matriz[linha][coluna]} ]')



    novamente = input('deseja continuar? [s/n]: ').lower()
    if novamente not in ('s', 'n'):
        print('tente novamente...')
        novamente = input('deseja continuar? [s/n]: ').lower()

    if novamente == 'n':
        break

print(f"""
A SUA LISTA FICOU ASSIM:
      
{matriz}
"""
)












